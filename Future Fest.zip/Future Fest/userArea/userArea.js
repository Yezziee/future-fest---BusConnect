
// Check if user is logged in
document.addEventListener('DOMContentLoaded', () => {
    const user = JSON.parse(localStorage.getItem('user'));
    if (!user) {
        window.location.href = '../login/login.html';
        return;
    }

    // Populate user data
    document.getElementById('userName').value = user.name || '';
    document.getElementById('userEmail').value = user.email || '';
});

// Tab handling
function showTab(tabId) {
    // Update active tab button
    document.querySelectorAll('.tab-button').forEach(button => {
        button.classList.remove('active');
    });
    document.querySelector(`[onclick="showTab('${tabId}')"]`).classList.add('active');

    // Show selected tab content
    document.querySelectorAll('.tab-content').forEach(content => {
        content.classList.remove('active');
    });
    document.getElementById(tabId).classList.add('active');
}

// Utility functions
function showMessage(message, type) {
    const messageClass = type === 'success' ? 'success-message' : 'error-message';
    const existingMessage = document.querySelector(`.${messageClass}`);
    if (existingMessage) {
        existingMessage.remove();
    }

    const messageElement = document.createElement('div');
    messageElement.className = messageClass;
    messageElement.textContent = message;

    const activeTab = document.querySelector('.tab-content.active');
    activeTab.insertBefore(messageElement, activeTab.firstChild);

    // Remove message after 3 seconds
    setTimeout(() => {
        messageElement.remove();
    }, 3000);
}

// Profile form handling
document.getElementById('profileForm').addEventListener('submit', async function(e) {
    e.preventDefault();
    
    const name = document.getElementById('userName').value.trim();
    const email = document.getElementById('userEmail').value.trim();
    
    if (!name || !email) {
        showMessage('Por favor, preencha todos os campos.', 'error');
        return;
    }

    try {
        // Simulate API call
        await new Promise(resolve => setTimeout(resolve, 1000));
        
        // Update local storage
        const user = JSON.parse(localStorage.getItem('user'));
        user.name = name;
        user.email = email;
        localStorage.setItem('user', JSON.stringify(user));
        
        showMessage('Perfil atualizado com sucesso!', 'success');
    } catch (error) {
        showMessage('Erro ao atualizar perfil. Tente novamente.', 'error');
    }
});

// Password form handling
document.getElementById('passwordForm').addEventListener('submit', async function(e) {
    e.preventDefault();

    const currentPassword = document.getElementById('currentPassword').value;
    const newPassword = document.getElementById('newPassword').value;
    const confirmNewPassword = document.getElementById('confirmNewPassword').value;

    if (!currentPassword || !newPassword || !confirmNewPassword) {
        showMessage('Por favor, preencha todos os campos.', 'error');
        return;
    }

    if (newPassword.length < 6) {
        showMessage('A nova senha deve ter pelo menos 6 caracteres.', 'error');
        return;
    }

    if (newPassword !== confirmNewPassword) {
        showMessage('As senhas não coincidem.', 'error');
        return;
    }

    try {
        // Simulate API call
        await new Promise(resolve => setTimeout(resolve, 1000));
        
        // In a real application, you would verify the current password
        // and update the password in your backend
        
        showMessage('Senha alterada com sucesso!', 'success');
        this.reset();
    } catch (error) {
        showMessage('Erro ao alterar senha. Tente novamente.', 'error');
    }
});

// Logout handling
function logout() {
    if (confirm('Tem certeza que deseja sair?')) {
        localStorage.removeItem('user');
        window.location.href = '../login/login.html';
    }
}

// Handle back navigation
window.addEventListener('popstate', () => {
    const user = localStorage.getItem('user');
    if (!user) {
        window.location.href = '../login/login.html';
    }
});

// Atualiza o arquivo userArea.js

// Adicione essa função para atualizar o usuário no localStorage
function updateUserData(name, email) {
    const user = JSON.parse(localStorage.getItem('user'));
    user.name = name;
    user.email = email;
    localStorage.setItem('user', JSON.stringify(user));
}

// Atualize o manipulador do profileForm
document.getElementById('profileForm').addEventListener('submit', async function(e) {
    e.preventDefault();
    
    const name = document.getElementById('userName').value.trim();
    const email = document.getElementById('userEmail').value.trim();
    
    if (!name || !email) {
        showMessage('Por favor, preencha todos os campos.', 'error');
        return;
    }

    try {
        // Simulate API call
        await new Promise(resolve => setTimeout(resolve, 1000));
        
        // Atualiza os dados do usuário no localStorage
        updateUserData(name, email);
        
        showMessage('Perfil atualizado com sucesso!', 'success');
    } catch (error) {
        showMessage('Erro ao atualizar perfil. Tente novamente.', 'error');
    }
});