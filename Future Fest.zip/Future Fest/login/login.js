// Mock database of users
const users = [
    {
        email: 'teste@exemplo.com',
        password: '123456',
        name: 'Usuário Teste'
    }
];


function validateEmail(email) {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email);
}

function validatePassword(password) {
    return password.length >= 6;
}

function showContainer(containerId) {
    document.querySelectorAll('.auth-container').forEach(container => {
        container.style.display = 'none';
    });
    document.getElementById(containerId).style.display = 'block';
    clearFeedback();
}

function showFeedback(formId, message, type) {
    clearFeedback();
    
    const feedback = document.createElement('div');
    feedback.className = `feedback ${type}`;
    feedback.textContent = message;

    // Add the feedback after the form
    const form = document.getElementById(formId);
    form.insertAdjacentElement('afterend', feedback);
}

function clearFeedback() {
    document.querySelectorAll('.feedback').forEach(el => el.remove());
}

function disableForm(formId, disabled = true) {
    const form = document.getElementById(formId);
    const button = form.querySelector('button');
    const inputs = form.querySelectorAll('input');
    
    button.disabled = disabled;
    inputs.forEach(input => input.disabled = disabled);
    
    if (disabled) {
        button.textContent = 'Processando...';
    } else {
        const originalText = {
            'loginForm': 'Entrar',
            'registerForm': 'Criar conta',
            'forgotForm': 'Enviar link'
        }[formId];
        button.textContent = originalText;
    }
}

// Login form handling
document.getElementById('loginForm').addEventListener('submit', async function(e) {
    e.preventDefault();
    clearFeedback();

    const email = document.getElementById('loginEmail').value.trim();
    const password = document.getElementById('loginPassword').value;
    
    // Validation
    if (!email || !password) {
        showFeedback('loginForm', 'Por favor, preencha todos os campos.', 'error');
        return;
    }

    if (!validateEmail(email)) {
        showFeedback('loginForm', 'Por favor, insira um e-mail válido.', 'error');
        return;
    }

    disableForm('loginForm', true);

    try {
        // Simulate API call
        await new Promise(resolve => setTimeout(resolve, 1500));
        
        // Check credentials against mock database
        const user = users.find(u => u.email === email && u.password === password);
        
        if (user) {
            showFeedback('loginForm', 'Login realizado com sucesso!', 'success');
            // Store user session
            localStorage.setItem('user', JSON.stringify({ email: user.email, name: user.name }));
            
            // Redirect after showing success message
            setTimeout(() => {
                window.location.href = '../home/home.html';
            }, 1000);
        } else {
            showFeedback('loginForm', 'E-mail ou senha incorretos.', 'error');
        }
    } catch (error) {
        showFeedback('loginForm', 'Erro ao fazer login. Tente novamente.', 'error');
    } finally {
        disableForm('loginForm', false);
    }
});

// Register form handling
document.getElementById('registerForm').addEventListener('submit', async function(e) {
    e.preventDefault();
    clearFeedback();

    const name = document.getElementById('registerName').value.trim();
    const email = document.getElementById('registerEmail').value.trim();
    const password = document.getElementById('registerPassword').value;
    const passwordConfirm = document.getElementById('registerPasswordConfirm').value;

    // Validation
    if (!name || !email || !password || !passwordConfirm) {
        showFeedback('registerForm', 'Por favor, preencha todos os campos.', 'error');
        return;
    }

    if (!validateEmail(email)) {
        showFeedback('registerForm', 'Por favor, insira um e-mail válido.', 'error');
        return;
    }

    if (!validatePassword(password)) {
        showFeedback('registerForm', 'A senha deve ter pelo menos 6 caracteres.', 'error');
        return;
    }

    if (password !== passwordConfirm) {
        showFeedback('registerForm', 'As senhas não coincidem.', 'error');
        return;
    }

    if (users.some(u => u.email === email)) {
        showFeedback('registerForm', 'Este e-mail já está cadastrado.', 'error');
        return;
    }

    disableForm('registerForm', true);

    try {
        // Simulate API call
        await new Promise(resolve => setTimeout(resolve, 1500));
        
        // Add user to mock database
        users.push({ email, password, name });
        
        showFeedback('registerForm', 'Conta criada com sucesso!', 'success');
        
        // Clear form
        this.reset();
        
        // Redirect to login after showing success message
        setTimeout(() => {
            showContainer('loginContainer');
        }, 1500);
    } catch (error) {
        showFeedback('registerForm', 'Erro ao criar conta. Tente novamente.', 'error');
    } finally {
        disableForm('registerForm', false);
    }
});

// Forgot password form handling
document.getElementById('forgotForm').addEventListener('submit', async function(e) {
    e.preventDefault();
    clearFeedback();

    const email = document.getElementById('forgotEmail').value.trim();

    if (!email) {
        showFeedback('forgotForm', 'Por favor, informe seu e-mail.', 'error');
        return;
    }

    if (!validateEmail(email)) {
        showFeedback('forgotForm', 'Por favor, insira um e-mail válido.', 'error');
        return;
    }

    disableForm('forgotForm', true);

    try {
        // Simulate API call
        await new Promise(resolve => setTimeout(resolve, 1500));
        
        // Check if user exists
        if (users.some(u => u.email === email)) {
            showFeedback('forgotForm', 'Link de recuperação enviado para seu e-mail!', 'success');
            this.reset();
        } else {
            showFeedback('forgotForm', 'E-mail não registrado.', 'error');
        }
    } catch (error) {
        showFeedback('forgotForm', 'Erro ao enviar link. Tente novamente.', 'error');
    } finally {
        disableForm('forgotForm', false);
    }
});

// Social login handling
function socialLogin(provider) {
    clearFeedback();
    showFeedback('loginForm', `Conectando com ${provider}...`, 'success');
    
    // Disable all social buttons
    document.querySelectorAll('.social-button').forEach(button => {
        button.disabled = true;
    });
    
    // Simulate social login process
    setTimeout(() => {
        showFeedback('loginForm', `Login com ${provider} realizado com sucesso!`, 'success');
        
        // Store mock user session
        localStorage.setItem('user', JSON.stringify({
            email: `user@${provider.toLowerCase()}.com`,
            name: `Usuário ${provider}`,
            provider: provider
        }));
        
        // Redirect after showing success message
        setTimeout(() => {
            window.location.href = '../home/home.html';
        }, 1000);
    }, 2000);
}


document.addEventListener('DOMContentLoaded', () => {
    const user = localStorage.getItem('user');
    if (user) {
        window.location.href = '../userArea/userArea.html';
    }
});