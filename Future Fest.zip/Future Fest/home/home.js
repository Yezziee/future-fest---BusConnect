document.addEventListener('DOMContentLoaded', function () {
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth'
                });
            }
        });
    });

    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };

    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }
        });
    }, observerOptions);

    document.querySelectorAll('.news-card').forEach(card => {
        card.style.opacity = '0';
        card.style.transform = 'translateY(20px)';
        card.style.transition = 'all 0.5s ease-out';
        observer.observe(card);
    });

    const updateNews = async () => {
        try {

            console.log('Notícias atualizadas');
        } catch (error) {
            console.error('Erro ao atualizar notícias:', error);
        }
    };
});

window.addEventListener('scroll', function () {
    const header = document.querySelector('.main-header');
    if (window.scrollY > 50) {
        header.classList.add('scrolled');
    } else {
        header.classList.remove('scrolled');
    }
});

document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            target.scrollIntoView({
                behavior: 'smooth'
            });
        }
    });
});

const observer = new IntersectionObserver(
    (entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }
        });
    },
    {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    }
);

document.querySelectorAll('.service-card').forEach(card => {
    card.style.opacity = '0';
    card.style.transform = 'translateY(20px)';
    card.style.transition = 'all 0.5s ease-out';
    observer.observe(card);
});

window.addEventListener('scroll', () => {
    const header = document.querySelector('.header');
    if (window.scrollY > 100) {
        header.classList.add('scrolled');
    } else {
        header.classList.remove('scrolled');
    }
});

document.querySelectorAll('.service-card').forEach(card => {
    card.addEventListener('click', function () {
        this.style.transform = 'scale(0.98)';
        setTimeout(() => {
            this.style.transform = 'scale(1)';
        }, 100);
    });
});
document.addEventListener('DOMContentLoaded', function () {
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const targetId = this.getAttribute('href').substring(1);
            const target = document.getElementById(targetId);
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth'
                });
            }
        });
    });

    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };

    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }
        });
    }, observerOptions);

    document.querySelectorAll('.news-card').forEach(card => {
        card.style.opacity = '0';
        card.style.transform = 'translateY(20px)';
        card.style.transition = 'all 0.5s ease-out';
        observer.observe(card);
    });

    const serviceObserver = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }
        });
    }, observerOptions);

    document.querySelectorAll('.service-card').forEach(card => {
        card.style.opacity = '0';
        card.style.transform = 'translateY(20px)';
        card.style.transition = 'all 0.5s ease-out';
        serviceObserver.observe(card);
    });

    window.addEventListener('scroll', function () {
        const header = document.querySelector('.main-header');
        if (window.scrollY > 50) {
            header.classList.add('scrolled');
        } else {
            header.classList.remove('scrolled');
        }
    });

    document.querySelectorAll('.service-card').forEach(card => {
        card.addEventListener('click', function () {
            this.style.transform = 'scale(0.98)';
            setTimeout(() => {
                this.style.transform = 'scale(1)';
            }, 100);
        });
    });
});

document.addEventListener('DOMContentLoaded', function () {
    function openModal(modalId) {
        const modal = document.getElementById(modalId);
        modal.classList.add('active');
        document.body.style.overflow = 'hidden';
    }

    function closeModal(modalId) {
        const modal = document.getElementById(modalId);
        modal.classList.remove('active');
        document.body.style.overflow = '';
    }

    document.querySelector('a[href="historico"]').addEventListener('click', function (e) {
        e.preventDefault();
        openModal('historicoModal');
    });



    document.querySelector('a[href="recarga"]').addEventListener('click', function (e) {
        e.preventDefault();
        openModal('recargaModal');
    });

    document.querySelector('a[href="segunda-via"]').addEventListener('click', function (e) {
        e.preventDefault();
        openModal('segundaViaModal');
    });

    document.querySelectorAll('.modal-close').forEach(button => {
        button.addEventListener('click', function () {
            const modalId = this.closest('.modal-overlay').id;
            closeModal(modalId);
        });
    });

    document.querySelectorAll('.modal-overlay').forEach(modal => {
        modal.addEventListener('click', function (e) {
            if (e.target === this) {
                closeModal(this.id);
            }
        });
    });

    document.querySelectorAll('.modal-container').forEach(container => {
        container.addEventListener('click', function (e) {
            e.stopPropagation();
        });
    });

    document.addEventListener('keydown', function (e) {
        if (e.key === 'Escape') {
            document.querySelectorAll('.modal-overlay.active').forEach(modal => {
                closeModal(modal.id);
            });
        }
    });


    document.querySelectorAll('form').forEach(form => {
        form.addEventListener('submit', function (e) {
            e.preventDefault();
            alert('Concluído!');
            closeModal(this.closest('.modal-overlay').id);
        });
    });
});

document.addEventListener('DOMContentLoaded', function () {

    const cpfInput = document.getElementById('cpf');
    if (cpfInput) {
        cpfInput.addEventListener('input', function (e) {
            let value = e.target.value.replace(/\D/g, '');
            if (value.length > 11) value = value.slice(0, 11);

            // Pra deixar nesse formato: 000.000.000-00
            if (value.length > 0) {
                value = value.replace(/^(\d{3})(\d)/g, '$1.$2');
                value = value.replace(/^(\d{3})\.(\d{3})(\d)/g, '$1.$2.$3');
                value = value.replace(/^(\d{3})\.(\d{3})\.(\d{3})(\d)/g, '$1.$2.$3-$4');
            }

            e.target.value = value;
        });
    }

    const telefoneInput = document.getElementById('telefone');
    if (telefoneInput) {
        telefoneInput.addEventListener('input', function (e) {
            let value = e.target.value.replace(/\D/g, '');
            if (value.length > 11) value = value.slice(0, 11);

            // Pra deixar nesse formato: (00) 00000-0000
            if (value.length > 0) {
                value = value.replace(/^(\d{2})(\d)/g, '($1) $2');
                value = value.replace(/^(\(\d{2}\))\ (\d{5})(\d)/g, '$1 $2-$3');
            }

            e.target.value = value;
        });
    }

    cpfInput?.addEventListener('keypress', function (e) {
        if (!/\d/.test(e.key) && e.key !== 'Backspace' && e.key !== 'Delete') {
            e.preventDefault();
        }
    });

    telefoneInput?.addEventListener('keypress', function (e) {
        if (!/\d/.test(e.key) && e.key !== 'Backspace' && e.key !== 'Delete') {
            e.preventDefault();
        }
    });
});

document.addEventListener('DOMContentLoaded', function () {
    function openModal(modalId) {
        const modal = document.getElementById(modalId);
        modal.classList.add('active');
        document.body.style.overflow = 'hidden';
    }

    function closeModal(modalId) {
        const modal = document.getElementById(modalId);
        modal.classList.remove('active');
        document.body.style.overflow = '';
    }

    document.querySelectorAll('.modal-close').forEach(button => {
        button.addEventListener('click', function () {
            const modalId = this.closest('.modal-overlay').id;
            closeModal(modalId);
        });
    });

    document.querySelectorAll('.modal-overlay').forEach(modal => {
        modal.addEventListener('click', function (e) {
            if (e.target === this) {
                closeModal(this.id);
            }
        });
    });

    document.querySelectorAll('.modal-container').forEach(container => {
        container.addEventListener('click', function (e) {
            e.stopPropagation();
        });
    });

    document.addEventListener('keydown', function (e) {
        if (e.key === 'Escape') {
            document.querySelectorAll('.modal-overlay.active').forEach(modal => {
                closeModal(modal.id);
            });
        }
    });

    document.addEventListener('DOMContentLoaded', function () {
        document.querySelector('a[href="recarga"]').addEventListener('click', function (e) {
            e.preventDefault();
            openModal('recargaModal');
        });

        document.getElementById('rechargeForm').addEventListener('submit', function (e) {
            e.preventDefault();

            const rechargeAmount = document.getElementById('recharge-amount').value;
            const paymentMethod = document.getElementById('payment-method').value;

            console.log('Recharging Bilhete Único:', { rechargeAmount, paymentMethod });

            this.reset();
            closeModal('recargaModal');
        });
    });
})

document.addEventListener('DOMContentLoaded', function () {
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const targetId = this.getAttribute('href').substring(1);
            const target = document.getElementById(targetId);
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth'
                });
            }
        });
    });

    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };

    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }
        });
    }, observerOptions);

    document.querySelectorAll('.news-card').forEach(card => {
        card.style.opacity = '0';
        card.style.transform = 'translateY(20px)';
        card.style.transition = 'all 0.5s ease-out';
        observer.observe(card);
    });

    const serviceObserver = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }
        });
    }, observerOptions);

    document.querySelectorAll('.service-card').forEach(card => {
        card.style.opacity = '0';
        card.style.transform = 'translateY(20px)';
        card.style.transition = 'all 0.5s ease-out';
        serviceObserver.observe(card);
    });

    window.addEventListener('scroll', function () {
        const header = document.querySelector('.main-header');
        if (window.scrollY > 50) {
            header.classList.add('scrolled');
        } else {
            header.classList.remove('scrolled');
        }
    });

    document.querySelectorAll('.service-card').forEach(card => {
        card.addEventListener('click', function () {
            this.style.transform = 'scale(0.98)';
            setTimeout(() => {
                this.style.transform = 'scale(1)';
            }, 100);
        });
    });
});

document.querySelectorAll('.modal-overlay').forEach(modal => {
    modal.addEventListener('click', function (e) {
        if (e.target === this) {
            closeModal(this.id);
        }
    });
});

document.querySelectorAll('.modal-container').forEach(container => {
    container.addEventListener('click', function (e) {
        e.stopPropagation();
    });
});

document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape') {
        document.querySelectorAll('.modal-overlay.active').forEach(modal => {
            closeModal(modal.id);
        });
    }
});

document.addEventListener("DOMContentLoaded", function () {
    const cardNumberInput = document.getElementById("cardNumber");
    const cardNameInput = document.getElementById("cardName");
    const cardExpiryInput = document.getElementById("cardExpiry");
    const cardCvvInput = document.getElementById("cardCvv");

    const numberDisplay = document.getElementById("numberDisplay");
    const nameDisplay = document.getElementById("nameDisplay");
    const expiryDisplay = document.getElementById("expiryDisplay");
    const cvvDisplay = document.getElementById("cvvDisplay");

    // Atualiza o número do cartão
    cardNumberInput.addEventListener("input", function () {
        numberDisplay.textContent = cardNumberInput.value || "•••• •••• •••• ••••";
    });

    // Atualiza o nome do titular do cartão
    cardNameInput.addEventListener("input", function () {
        nameDisplay.textContent = cardNameInput.value.toUpperCase() || "NOME DO TITULAR";
    });

    // Atualiza a data de validade do cartão
    cardExpiryInput.addEventListener("input", function () {
        expiryDisplay.textContent = cardExpiryInput.value || "MM/AA";
    });

    // Atualiza o CVV do cartão
    cardCvvInput.addEventListener("input", function () {
        cvvDisplay.textContent = cardCvvInput.value || "•••";
    });
});

document.addEventListener("DOMContentLoaded", function () {
    const cardNumberInput = document.getElementById("cardNumber");
    const cardNameInput = document.getElementById("cardName");
    const cardExpiryInput = document.getElementById("cardExpiry");
    const cardCvvInput = document.getElementById("cardCvv");

    const numberDisplay = document.getElementById("numberDisplay");
    const nameDisplay = document.getElementById("nameDisplay");
    const expiryDisplay = document.getElementById("expiryDisplay");
    const cvvDisplay = document.getElementById("cvvDisplay");

    cardNumberInput.addEventListener("input", function () {
        let value = cardNumberInput.value.replace(/\D/g, ""); // Remove caracteres que não são números
        value = value.replace(/(\d{4})(?=\d)/g, "$1 "); // Adiciona um espaço a cada 4 dígitos
        cardNumberInput.value = value.trim(); // Atualiza
        numberDisplay.textContent = value || "•••• •••• •••• ••••";
    });

    cardExpiryInput.addEventListener("input", function () {
        let value = cardExpiryInput.value.replace(/\D/g, ""); // Remove caracteres que não são números
        if (value.length > 2) {
            value = value.replace(/(\d{2})(\d)/, "$1/$2"); // Adiciona a barra depois de dois dígitos
        }
        cardExpiryInput.value = value; // Atualiza
        expiryDisplay.textContent = value || "MM/AA";
    });

    // Atualiza em tempo real o nome do titular
    cardNameInput.addEventListener("input", function () {
        nameDisplay.textContent = cardNameInput.value.toUpperCase() || "NOME DO TITULAR";
    });

    // Atualiza em tempo real o CVV
    cardCvvInput.addEventListener("input", function () {
        cvvDisplay.textContent = cardCvvInput.value || "•••";
    });
});

function togglePaymentFields() {
    const paymentMethod = document.getElementById("payment-method").value;
    const cardContainer = document.getElementById("cardContainer");
    const pixContainer = document.getElementById("pixContainer");

    if (paymentMethod === "credit-card" || paymentMethod === "debit-card") {
        cardContainer.style.display = "block";
        pixContainer.style.display = "none";
    } else if (paymentMethod === "pix") {
        cardContainer.style.display = "none";
        pixContainer.style.display = "block";
    } else {
        cardContainer.style.display = "none";
        pixContainer.style.display = "none";
    }
}

// Atualiza em tempo real os dados do cartão
document.addEventListener("DOMContentLoaded", function () {
    const cardNumberInput = document.getElementById("cardNumber");
    const cardNameInput = document.getElementById("cardName");
    const cardExpiryInput = document.getElementById("cardExpiry");
    const cardCvvInput = document.getElementById("cardCvv");

    const numberDisplay = document.getElementById("numberDisplay");
    const nameDisplay = document.getElementById("nameDisplay");
    const expiryDisplay = document.getElementById("expiryDisplay");
    const cvvDisplay = document.getElementById("cvvDisplay");

    cardNumberInput.addEventListener("input", function () {
        numberDisplay.textContent = cardNumberInput.value || "•••• •••• •••• ••••";
    });

    cardNameInput.addEventListener("input", function () {
        nameDisplay.textContent = cardNameInput.value.toUpperCase() || "NOME DO TITULAR";
    });

    cardExpiryInput.addEventListener("input", function () {
        expiryDisplay.textContent = cardExpiryInput.value || "MM/AA";
    });

    cardCvvInput.addEventListener("input", function () {
        cvvDisplay.textContent = cardCvvInput.value || "•••";
    });
});

document.addEventListener('DOMContentLoaded', function () {
    const card = document.querySelector('.card');
    const cvvInput = document.getElementById('cardCvv');

    cvvInput.addEventListener('focus', function () {
        card.classList.add('flipped');
    });

    cvvInput.addEventListener('blur', function () {
        card.classList.remove('flipped');
    });
});

document.addEventListener('DOMContentLoaded', () => {
    const Grid = document.querySelector('.news-grid');
    const nextButton = document.querySelector('.carousel-button.next');
    const prevButton = document.querySelector('.carousel-button.prev');
    let currentSlide = 0;
    const totalSlides = document.querySelectorAll('.news-card').length;
})



document.getElementById('cardCvv').addEventListener('focus', () => {
    const card = document.querySelector('.card');
    if (!card.classList.contains('flipped')) {
        card.classList.add('flipped');
    }
});

function formatarValor(valor) {
    const valorSpan = document.createElement('span');
    valorSpan.textContent = valor;
    valorSpan.classList.add('valor');

    if (parseFloat(valor.replace('R$ ', '').replace(',', '.')) >= 0) {
        valorSpan.classList.add('positivo');
    } else {
        valorSpan.classList.add('negativo');
    }

    return valorSpan;
}


function copyPixKey() {
    const pixKey = document.getElementById('pixKey');
    navigator.clipboard.writeText(pixKey.textContent).then(() => {
        alert('Chave PIX copiada com sucesso!');
    }).catch(err => {
        console.error('Erro ao copiar chave PIX:', err);
    });
}

function startPixTimer() {
    let timeLeft = 15 * 60; // 15 minutos em segundos
    const timerDisplay = document.getElementById('pixTimer');

    const timer = setInterval(() => {
        const minutes = Math.floor(timeLeft / 60);
        const seconds = timeLeft % 60;

        timerDisplay.textContent = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;

        if (timeLeft <= 0) {
            clearInterval(timer);
            timerDisplay.textContent = '00:00';
            alert('Tempo para pagamento expirado. Gere um novo QR Code.');
        }

        timeLeft--;
    }, 1000);
}

document.getElementById('payment-method').addEventListener('change', function () {
    if (this.value === 'pix') {
        startPixTimer();
    }
});